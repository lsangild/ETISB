///////////////////////////////////////////////////////////
//  Algorithm.cpp
//  Implementation of the Class Algorithm
//  Created on:      06-aug-2014 09:30:58
//  Original author: kbe
///////////////////////////////////////////////////////////

#include "Algorithm.h"

Algorithm::Algorithm()
{

}

Algorithm::~Algorithm()
{

}
